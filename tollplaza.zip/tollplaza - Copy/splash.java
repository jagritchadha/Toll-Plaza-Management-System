import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class splash extends JFrame
{
    ImageIcon s1,s2,s3,s4;
    JLabel l1,l2,l3,l4,l5;
    public splash()
    {
    setLayout(null);
    
    s1=new ImageIcon("poiuy.jpg");
    l1=new JLabel(s1);
    l1.setBounds(0,0,1410,730);

    s2=new ImageIcon("dik.png");
    l2=new JLabel(s2);
    l2.setBounds(10,3,830,120);

    s3=new ImageIcon("mov.gif");
    l3=new JLabel(s3);
    l3.setBounds(420,210,500,300);

    s4=new ImageIcon("qaz.png");
    l4=new JLabel(s4);
    l4.setBounds(500,600,900,90);
//add(l4);
add(l2);
add(l3);
add(l1);
}
public static void main(String args[])
{
   splash spl=new splash();
   spl.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   spl.setSize(1400,730);
   spl.setVisible(true);
   try
   {
   Thread.sleep(3000);
   midsrc m=new midsrc();
    m.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    m.setSize(1400,730);
    m.setVisible(true);

   }
   catch(Exception e){}
}
//spl.dispose();
}

