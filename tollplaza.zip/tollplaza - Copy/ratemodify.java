import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class ratemodify extends JFrame implements ActionListener
{
  ImageIcon r1,r2,r3,r4,r5,c8,c9;
  JLabel lvvtt,lowr,ltwr,lmpr,liimm,lhed,leb8,leb9;
  JTextField txtowr,txttwr,txtmpr;
  JComboBox cvvtt;
  JButton lr2,lr3,lr4,lr5;

  public ratemodify()
  {
  setLayout(null);

  r1=new ImageIcon("poiuyt.jpg");
  liimm=new JLabel(r1);
  liimm.setBounds(0,0,1400,730);

  c8=new ImageIcon("toll1.png");
  leb8=new JLabel(c8);
  leb8.setBounds(100,40,650,100);

  lvvtt=new JLabel("Vehicle Type");
  lvvtt.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,25));
  lvvtt.setForeground(Color.white);
  lvvtt.setBounds(770,300,180,50);

  cvvtt=new JComboBox();
  cvvt();
  cvvtt.setBounds(940,310,350,27);
  cvvtt.addFocusListener(new FocusAdapter()
{
public void focusLost(FocusEvent fe)
{
//int m;
//m=Integer.pars(cvvtt.getSelectedItem().toString());
try
  {
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  Statement stmt=con.createStatement();
  String query="Select * from tblrate where vehicletype='"+cvvtt.getSelectedItem()+"'";
  ResultSet rs=stmt.executeQuery(query);
  while(rs.next())
  {
  txtowr.setText(""+rs.getInt("onewayrate"));
  txttwr.setText(""+rs.getInt("twowayrate"));
  txtmpr.setText(""+rs.getInt("passholder"));
  }
  con.close();
  }
  catch(Exception e){
 System.out.println("Exception caught"+e);

}}});

  lowr=new JLabel("One Way Rate");
  lowr.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,25));
  lowr.setForeground(Color.white);
  lowr.setBounds(746,350,200,50);

  txtowr=new JTextField(18);
  txtowr.setBackground(Color.white);
  txtowr.setBounds(940,360,350,25);

  ltwr=new JLabel("Two Way Rate");
  ltwr.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,25));
  ltwr.setForeground(Color.white);
  ltwr.setBounds(746,400,250,50);

  txttwr=new JTextField(18);
  txttwr.setBackground(Color.white);  
  txttwr.setBounds(940,410,350,25);

  lmpr=new JLabel("Month Pass Rate");
  lmpr.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,25));
  lmpr.setForeground(Color.white);
  lmpr.setBounds(714,450,250,50);

  txtmpr=new JTextField(18);
  txtmpr.setBackground(Color.white);
  txtmpr.setBounds(940,460,350,25);

  r2=new ImageIcon("lr22.jpg");
  lr2=new JButton(r2);
  lr2.setBounds(940,520,110,32);
  lr2.addActionListener(this);

  r3=new ImageIcon("lr33.jpg");
  lr3=new JButton(r3);
  lr3.setBounds(1060,520,110,32);
  lr3.addActionListener(this);

  r4=new ImageIcon("lr44.jpg");
  lr4=new JButton(r4);
  lr4.setBounds(1180,520,110,32);
  lr4.addActionListener(this); 

  r5=new ImageIcon("mnb.jpg");
  lr5=new JButton(r5);
  lr5.setBounds(1230,80,110,32);
  lr5.addActionListener(this); 

  c9=new ImageIcon("car3.png");
  leb9=new JLabel(c9);
  leb9.setBounds(110,600,1167,109);


add(lvvtt);
add(cvvtt);
add(lowr);
add(txtowr);
add(ltwr);
add(txttwr);
add(lmpr);
add(txtmpr);
add(leb8);
add(lr2);
add(lr3);
add(lr4);
add(lr5);
add(leb9);
add(liimm);
}
public void cvvt()
{
try
  {
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  Statement stmt=con.createStatement();
  String query="Select vehicletype from tblrate";
  ResultSet rs=stmt.executeQuery(query);
  while(rs.next())
  {
  cvvtt.addItem(rs.getString("vehicletype"));
  }
  con.close();
  }
  catch(Exception e){
 System.out.println("Exception caught"+e);
}}



public void actionPerformed(ActionEvent ae)
{
  String s=ae.getActionCommand();
  lr2.setActionCommand("UPDATE");
  lr3.setActionCommand("DELETE");
  lr4.setActionCommand("EXIT");
  lr5.setActionCommand("BACK");

   if(s.equals("UPDATE"))
   {
    try
    {
     Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
     Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
     Statement stmt=con.createStatement();
     String query="Update tblrate set onewayrate="+txtowr.getText()+",twowayrate="+txttwr.getText()+",passholder="+txtmpr.getText()+" where vehicletype='"+cvvtt.getSelectedItem().toString()+"'";
  
  int x=stmt.executeUpdate(query);
  JOptionPane.showMessageDialog(null,"RATE UPDATE");
  con.close();
  }
  catch(Exception e){
 System.out.println("Exception caught"+e);
}}
else if(s.equals("DELETE"))
{
try
  {
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  Statement stmt=con.createStatement();
  String query="Delete from tblrate where vehicletype='"+cvvtt.getSelectedItem().toString()+"'";
  
  int x=stmt.executeUpdate(query);
  JOptionPane.showMessageDialog(null,"RATE DELETED");
  txtowr.setText("");
  txttwr.setText("");
  txtmpr.setText("");
  con.close();
  }
  catch(Exception e){
 System.out.println("Exception caught"+e);
}
     cvvtt.removeAllItems();
     cvvt();     
}

else if(s.equals("CLEAR"))
{
txtowr.setText("");
txttwr.setText("");
txtmpr.setText(""); 
}

else if(s.equals("BACK"))
{
   dispose();
   adminsrc admi=new adminsrc();
   admi.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   admi.setTitle("Admin Screen");
   admi.setSize(1400,730);
   admi.setVisible(true);
}

else if(s.equals("EXIT"))
{
int x=JOptionPane.showConfirmDialog(null,"Are you sure??");
if(x==JOptionPane.YES_OPTION)
{
System.exit(0);
}
}


}
public static void main(String args[])
{
  ratemodify rat=new ratemodify();
  rat.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  rat.setTitle("RateInsertion");
  rat.setSize(1400,730);
  rat.setVisible(true);
 }
}