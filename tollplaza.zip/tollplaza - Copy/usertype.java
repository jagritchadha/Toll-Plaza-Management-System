import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class usertype extends JFrame implements ActionListener
{
   ImageIcon u1,u2,u3,u4,u5,u6,u7,u8,c8,c9;
   JButton butnew,butold,butpass;
   JLabel lheader,limg,lnew,lold,lpas,leb8,leb9;
   public usertype()
   {

  u1=new ImageIcon("poiuyt.jpg");
  limg=new JLabel(u1);
  limg.setBounds(0,0,1400,730);

  c8=new ImageIcon("toll1.png");
  leb8=new JLabel(c8);
  leb8.setBounds(100,20,650,100);   
   
   u2=new ImageIcon("new.jpg");
   lnew=new JLabel(u2); 
   lnew.setBounds(35,238,400,240);  
  
   u3=new ImageIcon("old.jpg");
   lold=new JLabel(u3); 
   lold.setBounds(480,240,400,240);  

   u4=new ImageIcon("pas.jpg");
   lpas=new JLabel(u4); 
   lpas.setBounds(925,238,400,245);  
 
  /* u5=new ImageIcon("u.png");
   lheader=new JLabel(u5);
   //lheader.setFont(new Font("Harlow Solid",Font.BOLD|Font.ITALIC,72));
   //lheader.setForeground(Color.green);
   lheader.setBounds(20,30,400,90);*/

   u6=new ImageIcon("but1.jpg");
   butnew=new JButton(u6);
   butnew.setBounds(128,505,220,40);
   butnew.addActionListener(this);

   u7=new ImageIcon("but2.jpg");
   butold=new JButton(u7);
   butold.setBounds(570,505,218,39);
   butold.addActionListener(this);

   u8=new ImageIcon("but3.jpg");
   butpass=new JButton(u8);;
   butpass.setBounds(1020,505,218,39);
   butpass.addActionListener(this);

  c9=new ImageIcon("car3.png");
  leb9=new JLabel(c9);
  leb9.setBounds(110,580,1167,104);

add(lnew);
add(lold);
add(lpas);
//add(lheader);
add(butnew);
add(butold);
add(butpass);
add(leb8);
add(leb9);
add(limg);
}
public void actionPerformed(ActionEvent ae)
{
  String s=ae.getActionCommand();
  butnew.setActionCommand("New");
  butold.setActionCommand("Old");
  butpass.setActionCommand("Pass");
  if(s.equals("New"))
  {
  dispose();
  newslip slip=new newslip();
  slip.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  slip.setSize(1400,735);
  slip.setVisible(true);
  }
  else if(s.equals("Old"))
  {
  dispose();
  oldslip slp=new oldslip();
  slp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  slp.setSize(1400,735);
  slp.setVisible(true);
  }
  else if(s.equals("Pass"))
  {
  dispose();
  passval val=new passval();
  val.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  val.setSize(1400,730);
  val.setVisible(true);
  }
}
public static void main(String args[])
{
  usertype user=new usertype();
  user.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  user.setTitle("Payment Type");
  user.setSize(1400,730);
  user.setVisible(true);
  //DISPOSE();
}
}