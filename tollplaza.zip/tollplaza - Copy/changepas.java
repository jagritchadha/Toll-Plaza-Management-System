import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class changepas extends JFrame implements ActionListener
{
  ImageIcon c1,c2,c3,c4,c8,c9;
  JLabel luid,lcpas,lnpas,lrpas,lc1,lc2,lc3,lh,leb8,leb9;
  JComboBox txtid;
  JPasswordField txtcpas,txtnpas,txtrpas;
  JButton bchng,bback,bexit;
  public changepas()
  {
  setLayout(null);

  c1=new ImageIcon("poiuyt.jpg");
  lc1=new JLabel(c1);
  lc1.setBounds(0,0,1400,730);

  c8=new ImageIcon("toll1.png");
  leb8=new JLabel(c8);
  leb8.setBounds(100,40,650,100);

  luid=new JLabel("User Id");
  luid.setFont(new Font("Imprint MT Shadow",Font.BOLD|Font.ITALIC,25));
  luid.setForeground(Color.white);
  luid.setBounds(600,290,100,50);

  txtid=new JComboBox();
  txtid();
  txtid.setBounds(720,300,350,27);
  txtid.setBackground(Color.white);
  txtid.addFocusListener(new FocusAdapter()
  {
   public void focusLost(FocusEvent fe)
   {
    try
     {
     Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
     Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
     Statement stmt=con.createStatement();
     String query="Select * from tbllogin where userid='"+txtid.getSelectedItem()+"'";
     ResultSet rs=stmt.executeQuery(query);
     while(rs.next())
     {
     txtcpas.setText(""+rs.getString("password"));
     }
     con.close();
     }
     catch(Exception e){
     System.out.println("Exception caught"+e);
                       }
  }
 }); 

  lcpas=new JLabel("Current Password");
  lcpas.setFont(new Font("Imprint MT Shadow",Font.BOLD|Font.ITALIC,25));
  lcpas.setForeground(Color.white);
  lcpas.setBounds(481,340,300,50);

  txtcpas=new JPasswordField(18);
  txtcpas.setBounds(720,350,350,27);
  txtcpas.setBackground(Color.white);

  lnpas=new JLabel("New Password");
  lnpas.setFont(new Font("Imprint MT Shadow",Font.BOLD|Font.ITALIC,25));
  lnpas.setForeground(Color.white);
  lnpas.setBounds(514,390,300,50);

  txtnpas=new JPasswordField(18);
  txtnpas.setBounds(720,400,350,27);
  txtnpas.setBackground(Color.white);

  lrpas=new JLabel("Re-Type Password");
  lrpas.setFont(new Font("Imprint MT Shadow",Font.BOLD|Font.ITALIC,25));
  lrpas.setForeground(Color.white);
  lrpas.setBounds(464,440,300,50);

  txtrpas=new JPasswordField(18);
  txtrpas.setBounds(720,450,350,27);
  txtrpas.setBackground(Color.white);
  txtrpas.addFocusListener(new FocusAdapter()
   {
    public void focusLost(FocusEvent fe)
    {
     String n=txtnpas.getText();
     String r=txtrpas.getText();
    if(n.equals(""+r))
    {
     JOptionPane.showMessageDialog(null,"Confirm Password");
    }
     else
     {
     JOptionPane.showMessageDialog(null,"Password Must Be Same");
     txtnpas.setText("");
     txtrpas.setText("");
     }
}});

  c2=new ImageIcon("chp.jpg");
  bchng=new JButton(c2);
  bchng.setBounds(725,495,340,35);
  bchng.addActionListener(this);

  c3=new ImageIcon("bvc.jpg");
  bback=new JButton(c3);
  bback.setBounds(725,546,153,32);
  bback.addActionListener(this);

  c4=new ImageIcon("xi.jpg");
  bexit=new JButton(c4);
  bexit.setBounds(910,546,155,32);
  bexit.addActionListener(this);

  c9=new ImageIcon("car3.png");
  leb9=new JLabel(c9);
  leb9.setBounds(110,600,1167,104);

add(luid);
add(txtid);
add(lcpas);
add(txtcpas);
add(lnpas);
add(txtnpas);
add(lrpas);
add(txtrpas);
//add(lh);
add(bchng);
add(bback);
add(bexit);
add(leb8);
add(leb9);
add(lc1);
}

public void txtid()
{
  try
  {
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  Statement stmt=con.createStatement();
  String query="Select userid from tbllogin";
  ResultSet rs=stmt.executeQuery(query);
  while(rs.next())
  {
  txtid.addItem(rs.getString("userid"));
  }
  con.close();
  }
  catch(Exception e){
 System.out.println("Exception caught"+e);
}}


public void actionPerformed(ActionEvent ae)
{
String s=ae.getActionCommand();
bchng.setActionCommand("Changepassword");
bback.setActionCommand("Back");
bexit.setActionCommand("Exit");
  if(s.equals("Changepassword"))
   {
     try
      {
       Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
       Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
       Statement stmt=con.createStatement();
       String query="Update tbllogin set password='"+txtnpas.getText()+"' where userid='"+txtid.getSelectedItem().toString()+"'";
  
       int x=stmt.executeUpdate(query);
       JOptionPane.showMessageDialog(null,"PASSWORD UPDATES.....");
       con.close();
     }
  catch(Exception e){
 System.out.println("Exception caught"+e);
} 
}
  
else if(s.equals("Back"))
{
   dispose();
   adminsrc admi=new adminsrc();
   admi.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   admi.setTitle("Admin Screen");
   admi.setSize(1400,730);
   admi.setVisible(true);
}
else if(s.equals("Exit"))
{
int x=JOptionPane.showConfirmDialog(null,"Are You Sure??");
if(x==JOptionPane.YES_OPTION)
 {
  System.exit(0);
  }
}
}
public static void main(String args[])
{
  changepas pas=new changepas();
  pas.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  pas.setTitle("Password Change");
  pas.setSize(1400,730);
  pas.setVisible(true);
}
}