import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import java.text.*;
public class newslip extends JFrame implements ActionListener
{
  ImageIcon g1,g2,g3,g4,c8,c9;
  JLabel limgg,lhead,lsn,lvn,lvt,ljt,ldt,latp,lsvt,leb8,leb9;
  JTextField txtsn,txtvn,txtdt,txtatp,txtsvt;
  JComboBox cvt,cjt;
  JButton butgen,butcan,butbb;
  String journey[]={"One Way","Two Way"}; 

  public newslip()
  {
  g1=new ImageIcon("poiuyt.jpg");
  limgg=new JLabel(g1);
  limgg.setBounds(0,0,1400,730);

  c8=new ImageIcon("toll1.png");
  leb8=new JLabel(c8);
  leb8.setBounds(100,20,650,100);

  lsn=new JLabel("Slip No.");
  lsn.setFont(new Font("Franklin Gothic",Font.BOLD|Font.ITALIC,27));
  lsn.setForeground(Color.white);
  lsn.setBounds(797,150,180,50);

  txtsn=new JTextField(18);
  runid();
  txtsn.setBackground(Color.white);
  txtsn.setBounds(940,160,350,27);
  //txtsn.setEditable(false);

  lvn=new JLabel("Vehicle No.");
  lvn.setFont(new Font("Franklin Gothic",Font.BOLD|Font.ITALIC,27));
  lvn.setForeground(Color.white);
  lvn.setBounds(755,200,200,50);

  txtvn=new JTextField(18);
  txtvn.setBackground(Color.white);
  txtvn.setBounds(940,210,350,27);

  lvt=new JLabel("Vehicle Type");
  lvt.setFont(new Font("Franklin Gothic",Font.BOLD|Font.ITALIC,27));
  lvt.setForeground(Color.white);
  lvt.setBounds(730,250,180,50);

  cvt=new JComboBox();
  cvt();
  cvt.setBounds(940,260,350,30);

  ljt=new JLabel("Journey Type");
  ljt.setFont(new Font("Franklin Gothic",Font.BOLD|Font.ITALIC,27));
  ljt.setForeground(Color.white);
  ljt.setBounds(718,300,180,50);

  cjt=new JComboBox(journey);
  cjt.setBounds(940,310,350,30);
  cjt.addFocusListener(new FocusAdapter()
   {
    public void focusLost(FocusEvent fe)
     {
       try
       {
         Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
         Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
         Statement stmt=con.createStatement();
         String query="Select * from tblrate where vehicletype='"+cvt.getSelectedItem()+"'";
         ResultSet rs=stmt.executeQuery(query);
         rs.next(); 
	 if(cjt.getSelectedItem()=="One Way")
         {
          txtatp.setText(""+rs.getInt("onewayrate"));
          txtsvt.setText("");
         }
         else
         {
          txtatp.setText(""+rs.getInt("twowayrate"));
          Calendar cal1=Calendar.getInstance();
          cal1.add(Calendar.DAY_OF_MONTH,1);
          SimpleDateFormat sdf1=new SimpleDateFormat("dd-MM-yyyy HH:mm");
          String s1=sdf1.format(cal1.getTime());
          txtsvt.setText(s1);
          txtsvt.setEditable(false);
         }
      con.close();
}
catch(Exception e){
System.out.println("Exception:"+e);
}
}});

  ldt=new JLabel("Current Date/Time");
  ldt.setFont(new Font("Franklin Gothic",Font.BOLD|Font.ITALIC,27));
  ldt.setForeground(Color.white);
  ldt.setBounds(670,350,250,50);

  txtdt=new JTextField(18);
  //txtdt.setBackground(Color.white);
  txtdt.setBounds(940,360,350,27);
  txtdt.setEditable(false);

  Calendar cal=Calendar.getInstance();
  cal.add(Calendar.DAY_OF_MONTH,1);
  SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy/HH:mm");
  String s=sdf.format(new Date());
  txtdt.setText(""+s);


  latp=new JLabel("Amount To Pay");
  latp.setFont(new Font("Franklin Gothic",Font.BOLD|Font.ITALIC,27));
  latp.setForeground(Color.white);
  latp.setBounds(700,400,250,50);

  txtatp=new JTextField(18);
  txtatp.setBackground(Color.white);
  txtatp.setBounds(940,410,350,27);
  txtatp.setEditable(false);

  lsvt=new JLabel("Slip Validity Time");
  lsvt.setFont(new Font("Franklin Gothic",Font.BOLD|Font.ITALIC,27));
  lsvt.setForeground(Color.white);
  lsvt.setBounds(680,450,250,50);

  txtsvt=new JTextField(18);
  txtsvt.setBackground(Color.white);
  txtsvt.setBounds(940,460,350,27);
  txtsvt.setEditable(false);

 /* Calendar cal1=Calendar.getInstance();
  cal1.add(Calendar.DAY_OF_MONTH,1);
  SimpleDateFormat sdf1=new SimpleDateFormat("dd-MM-yyyy");
  String s1=sdf1.format(cal1.getTime());
  txtsvt.setText(s1);
  txtsvt.setEditable(false); */

  g2=new ImageIcon("b1.jpg");
  butgen=new JButton(g2);
  butgen.setBounds(942,510,226,40);
  butgen.addActionListener(this);

  g3=new ImageIcon("b2.jpg");
  butcan=new JButton(g3);
  butcan.setBounds(1185,510,100,40);
  butcan.addActionListener(this);

  g4=new ImageIcon("mnb.jpg");
  butbb=new JButton(g4);
  butbb.setBounds(1250,42,80,30);
  butbb.addActionListener(this);

  c9=new ImageIcon("car5.png");
  leb9=new JLabel(c9);
  leb9.setBounds(130,600,1142,99);

add(lsn);
add(txtsn);
add(lvn);
add(txtvn);
add(lvt);
add(cvt);
add(ljt);
add(cjt);
add(ldt);
add(txtdt);
add(latp);
add(txtatp);
add(lsvt);
add(txtsvt);
add(butgen);
add(butcan);
add(butbb);
add(leb8);
add(leb9);
add(limgg);
}
public void cvt()
{
try
  {
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  Statement stmt=con.createStatement();
  String query="Select vehicletype from tblrate";
  ResultSet rs=stmt.executeQuery(query);
  while(rs.next())
  {
  cvt.addItem(rs.getString("vehicletype"));
  }
  con.close();
  }
  catch(Exception e){
 System.out.println("Exception caught"+e);
}}

public void actionPerformed(ActionEvent ae)
{
String s=ae.getActionCommand();
butgen.setActionCommand("Generateslip");
butcan.setActionCommand("Cancal");
butbb.setActionCommand("Back");
  if(s.equals("Generateslip"))
  {
    if(txtvn.getText().equals("") || txtatp.getText().equals(""))
            {
            JOptionPane.showMessageDialog(null,"FIELDS SHOULD NOT BE EMPTY");
            }
     else
     {
     try
     {
     Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
     Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
     Statement stmt=con.createStatement();
     String query="Insert into tblnewslip(slipno,vehicleno,vehicletype,journeytype,amount,currentdate,slipvaltime) values ("+txtsn.getText()+",'"+txtvn.getText()+"','"+cvt.getSelectedItem().toString()+"','"+cjt.getSelectedItem().toString()+"','"+txtatp.getText()+"','"+txtdt.getText()+"','"+txtsvt.getText()+"')";
     int x=stmt.executeUpdate(query);
     JOptionPane.showMessageDialog(null,"SLIP GENERATED.......");
     con.close();
  }
  catch(Exception e){
System.out.println("Exception Caught"+e);
}}}

  else if(s.equals("Back"))
   {
    dispose();
    usertype user=new usertype();
    user.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    user.setTitle("Payment Type");
    user.setSize(1400,730);
    user.setVisible(true);
   } 

  else if(s.equals("Cancal"))
   {
   txtvn.setText("");
   txtatp.setText("");
   txtsvt.setText("");
   }
}

public void runid()
{
   try
    {
   int a=0;
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  Statement stmt=con.createStatement();
  String query="Select slipno from tblnewslip";
  ResultSet rs=stmt.executeQuery(query);
  while(rs.next())
  {
  a=rs.getInt("slipno");
  }
  if(a==0)
  {
   txtsn.setText("1881");
}
   else
   {
   txtsn.setText(String.valueOf(a+1));
}
  con.close();
  }
  catch(Exception e){
 System.out.println("Exception caught"+e);
}}

public static void main(String args[])
{
  newslip slip=new newslip();
  slip.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  slip.setSize(1400,730);
  slip.setTitle("Generate New Slip");
  slip.setVisible(true);
}
}