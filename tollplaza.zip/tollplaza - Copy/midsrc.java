import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class midsrc extends JFrame implements ActionListener
{
  ImageIcon c1,c2,c3,c4,c5,c6,c8,c9,c10,c11;
  JLabel leb1,leb2,leb3,leb4,leb8,leb9,leb10,leb11;
  JPasswordField pas1;
  JButton buser,badmin,bexit;
  char ch;
  public midsrc()
  {
  setLayout(null);

  c1=new ImageIcon("poiuyt.jpg");
  leb1=new JLabel(c1);
  leb1.setBounds(0,0,1400,730);

  c8=new ImageIcon("toll1.png");
  leb8=new JLabel(c8);
  leb8.setBounds(100,40,650,100);

  c2=new ImageIcon("ioo.jpg");
  leb2=new JLabel(c2);
  leb2.setBounds(420,280,200,115);

  pas1=new JPasswordField();
  pas1.setBounds(432,440,250,28);
  pas1.setVisible(false);

   c3=new ImageIcon("pok.jpg");
  leb3=new JLabel(c3);
  leb3.setBounds(750,280,200,115);

  c4=new ImageIcon("adm.jpg");
  badmin=new JButton(c4);
  badmin.setBounds(453,410,130,30);
  badmin.addActionListener(this);

  c5=new ImageIcon("shetal.jpg");
  buser=new JButton(c5);
  buser.setBounds(788,410,130,30);
  buser.addActionListener(this);

   c6=new ImageIcon("b7.jpg");
  bexit=new JButton(c6);
  bexit.setBounds(1230,88,110,29);
  bexit.addActionListener(this);

  c9=new ImageIcon("car4.png");
  leb9=new JLabel(c9);
  leb9.setBounds(130,600,1165,99);

add(pas1);
add(leb3);
add(leb2);
add(leb8);
add(badmin);
add(buser);
add(bexit);
add(leb9);
add(leb1);
}

public void actionPerformed(ActionEvent ae)
{
String s=ae.getActionCommand();
badmin.setActionCommand("Admin");
buser.setActionCommand("User");
bexit.setActionCommand("Exit");

if(s.equals("Admin"))
{
pas1.setVisible(true);
     if(pas1.getText().equals("1234567"))
      {
       dispose();
                          adminsrc admi=new adminsrc();
                          admi.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                          admi.setTitle("Admin Screen");
                          admi.setSize(1400,730);
                          admi.setVisible(true);
      }
     else if(!(pas1.getText().equals("1234567")))
      {
          JOptionPane.showMessageDialog(null,"Wrong Password");
  } 
}  
else if(s.equals("User"))
{
   dispose();
   signin in=new signin();
   Thread thread=new Thread(in);
   thread.start();
   in.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   in.setTitle("User Login");
   in.setSize(1400,730);
   in.setVisible(true);
}
else if(s.equals("Exit"))
{
int x=JOptionPane.showConfirmDialog(null,"Are You Sure??");
if(x==JOptionPane.YES_OPTION)
 {
  System.exit(0);
  }
} 
}
public static void main(String args[])
{
  midsrc m=new midsrc();
  m.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  m.setSize(1400,730);
  m.setVisible(true);
}
}