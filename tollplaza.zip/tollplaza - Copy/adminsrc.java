import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class adminsrc extends JFrame implements ActionListener
{
   ImageIcon a1,a2,a3,a4;
   JLabel l;
   BackgroundMenuBar mbar;
   JMenu mlog,mrat,mpas,mrep,mqut;
   JMenuItem mi1,mi2,mi3,mi4,mi5,mi6,mi7,mi8,mi9,mi10,mi11,mi12,mi13;
   public adminsrc()
   {
   setLayout(null);
  
   a1=new ImageIcon("dikk.jpg");
   l=new JLabel(a1);
   l.setBounds(0,0,1400,665);

   mbar=new BackgroundMenuBar();
   setJMenuBar(mbar);
   
   //a2=new ImageIcon("admlog.jpg");
   mlog=new JMenu("Login");
   mlog.setMnemonic('L');
   mbar.add(mlog);
        mi1=new JMenuItem("Create User",new ImageIcon("kkk.png"));
        //mi1.setFont(new Font("Constantia",Font.BOLD,15));
        //mi1.setForeground(Color.blue);
        mi1.addActionListener(this);
        mlog.add(mi1);

        mlog.addSeparator();
        mi2=new JMenuItem("Modified User",new ImageIcon("us.png"));
        //mi2.setFont(new Font("Constantia",Font.BOLD,15));
        //mi2.setForeground(Color.blue);
        mi2.addActionListener(this);
        mlog.add(mi2);

        mlog.addSeparator();
        mi3=new JMenuItem("Change Password",new ImageIcon("nav-login2.png"));
        //mi3.setFont(new Font("Constantia",Font.BOLD,15));
        //mi3.setForeground(Color.blue);
        mi3.addActionListener(this);
        mlog.add(mi3);
    
        mlog.addSeparator();
        mi4=new JMenuItem("Show Username/Password",new ImageIcon("ss.png"));
        //mi4.setFont(new Font("Constantia",Font.BOLD,15));
        //mi4.setForeground(Color.blue);
        mi4.addActionListener(this);
        mlog.add(mi4);

  mrat=new JMenu("RateList");
  mrat.setMnemonic('R');
  mbar.add(mrat);
        mi5=new JMenuItem("Insertion",new ImageIcon("p2s.png"));
        //mi5.setFont(new Font("Constantia",Font.BOLD,15));
        //mi5.setForeground(Color.blue);
        mi5.addActionListener(this);
        mrat.add(mi5);
        
        mrat.addSeparator();
        mi6=new JMenuItem("Modification",new ImageIcon("mod.png"));
        //mi6.setFont(new Font("Constantia",Font.BOLD,15));
        //mi6.setForeground(Color.blue);
        mi6.addActionListener(this);
        mrat.add(mi6);

  mpas=new JMenu("Pass");
  mpas.setMnemonic('P');
  mbar.add(mpas);
        mi7=new JMenuItem("Generate Pass",new ImageIcon("lkj.png"));
        //mi7.setFont(new Font("Constantia",Font.BOLD,15));
        //mi7.setForeground(Color.blue);
        mi7.addActionListener(this);
        mpas.add(mi7);

  mrep=new JMenu("Report");
  mrep.setMnemonic('r');
  mbar.add(mrep);
        mi8=new JMenuItem("Login Stock",new ImageIcon("logg.png"));
        //mi8.setFont(new Font("Constantia",Font.BOLD,15));
        //mi8.setForeground(Color.blue);
        mi8.addActionListener(this);
        mrep.add(mi8);

        mrep.addSeparator();
        mi9=new JMenuItem("New Slip Stock",new ImageIcon("slip.png"));
        //mi9.setFont(new Font("Constantia",Font.BOLD,15));
        //mi9.setForeground(Color.blue);
        mi9.addActionListener(this);
        mrep.add(mi9);
 
       /* mrep.addSeparator();
        mi10=new JMenuItem("Pass Validity Stock",new ImageIcon("a.png"));
        //mi10.setFont(new Font("Constantia",Font.BOLD,15));
        //mi10.setForeground(Color.blue);
        mi10.addActionListener(this);
        mrep.add(mi10); */

        mrep.addSeparator();
        mi11=new JMenuItem("Vehicle Type Stock",new ImageIcon("a.png"));
        //mi11.setFont(new Font("Constantia",Font.BOLD,15));
        //mi11.setForeground(Color.blue);
        mi11.addActionListener(this);
        mrep.add(mi11);
  
        mrep.addSeparator();
        mi12=new JMenuItem("New Pass Stock",new ImageIcon("images.png"));
        //mi12.setFont(new Font("Constantia",Font.BOLD,15));
        //mi12.setForeground(Color.blue);
        mi12.addActionListener(this);
        mrep.add(mi12);
mqut=new JMenu("Quit");
mqut.setMnemonic('Q');
mbar.add(mqut);

        mi13=new JMenuItem("Exit App",new ImageIcon("lkjj.png"));
        //mi13.setFont(new Font("Constantia",Font.BOLD,15));
        //mi13.setForeground(Color.blue);
        mi13.addActionListener(this);
        mqut.add(mi13);

add(l);
}
public void actionPerformed(ActionEvent ae)
{
   String s=ae.getActionCommand();
   if(s.equals("Create User"))
   {
    dispose();
    signup up=new signup();
    up.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    up.setTitle("Create New User");
    up.setSize(1400,730);
    up.setVisible(true);
   }
   else if(s.equals("Modified User"))
   {
    dispose();
    modifyuser mod=new modifyuser();
    mod.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    mod.setTitle("Modified User");
    mod.setSize(1400,730);
    mod.setVisible(true);
    }
    else if(s.equals("Change Password"))
    {
    dispose();
    changepas pas=new changepas();
    pas.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pas.setTitle("Password Change");
    pas.setSize(1400,730);
    pas.setVisible(true);
    }
    else if(s.equals("Show Username/Password"))
    {
    dispose();
    showuserpass pas12=new showuserpass();
    pas12.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pas12.setTitle("Show Username/Password");
    pas12.setSize(1400,730);
    pas12.setVisible(true);
    }
    else if(s.equals("Insertion"))
    {
    dispose();
    rateinsert rate=new rateinsert();
    rate.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    rate.setTitle("RateInsertion");
    rate.setSize(1400,730);
    rate.setVisible(true);
    }
    else if(s.equals("Modification"))
    {
    dispose();
    ratemodify rat=new ratemodify();
    rat.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    rat.setTitle("RateInsertion");
    rat.setSize(1400,730);
    rat.setVisible(true);
    }
    else if(s.equals("Generate Pass"))
    {
    dispose();
    genpass gen=new genpass();
    gen.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    gen.setTitle("Generate Pass");
    gen.setSize(1400,730);
    gen.setVisible(true);
   }
   else if(s.equals("Login Stock"))
   {
    dispose();
    loginstock log=new loginstock();
    log.setVisible(true);
    log.setSize(1400,730);
   }
   else if(s.equals("New Slip Stock"))
   {
    dispose();
    slipstock sl=new slipstock();
    sl.setVisible(true);
    sl.setSize(1400,730);
   }
   else if(s.equals("Vehicle Type Stock"))
   {
    dispose();
    ratestock ra=new ratestock();
    ra.setVisible(true);
    ra.setSize(1400,730);
   }
   else if(s.equals("New Pass Stock"))
   {
    dispose();
    passtock pa=new passtock();
    pa.setVisible(true);
    pa.setSize(1400,730);
   }

  else if(s.equals("Exit App"))
  {
  int x=JOptionPane.showConfirmDialog(null,"ARE YOU SURE?");
  if(x==JOptionPane.YES_OPTION)
  { System.exit(0); }
}
     
}
public static void main(String args[])
{
   adminsrc admi=new adminsrc();
   admi.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   admi.setTitle("Admin Screen");
   admi.setSize(1400,730);
   admi.setVisible(true);
}
class BackgroundMenuBar extends JMenuBar
{
    Color bgColor=Color.white;

    public void setColor(Color color)
    {
        bgColor=color;
    }

    @Override
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(bgColor);
        g2d.fillRect(0, 0, getWidth() - 1, getHeight() - 1);

    }
}
}    