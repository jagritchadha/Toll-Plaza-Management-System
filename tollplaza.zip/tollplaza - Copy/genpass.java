import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import java.text.*;
public class genpass extends JFrame implements ActionListener
{
  int i,k;
  ImageIcon p1,p2,p3,p4,c8,c9;
  JLabel lhad,lrun,lveh,lvety,lstar,lupto,lamt,lii,lmm,laa,leb8,leb9;
  JTextField txtrun,txtveh,txtstar,txtupto,txtamt;
  JComboBox cvety;
  JButton btgen,btcan,btbac;

  public genpass()
  {
  setLayout(null);

  p1=new ImageIcon("poiuyt.jpg");
  lii=new JLabel(p1);
  lii.setBounds(0,0,1400,730);

  c8=new ImageIcon("toll1.png");
  leb8=new JLabel(c8);
  leb8.setBounds(100,40,650,100);

  lrun=new JLabel("Run Id");
  lrun.setFont(new Font("Corbel",Font.BOLD|Font.ITALIC,30));
  lrun.setForeground(Color.white);
  lrun.setBounds(797,150,180,50);

  txtrun=new JTextField(18);
  runid();
  txtrun.setBackground(Color.white);
  txtrun.setBounds(940,160,350,27);
  txtrun.setEditable(false);

  lveh=new JLabel("Vehicle No.");
  lveh.setFont(new Font("Corbel",Font.BOLD|Font.ITALIC,30));
  lveh.setForeground(Color.white);
  lveh.setBounds(755,200,200,50);

  txtveh=new JTextField(18);
  txtveh.setBackground(Color.white);
  txtveh.setBounds(940,210,350,27);

  lvety=new JLabel("Vehicle Type");
  lvety.setFont(new Font("Corbel",Font.BOLD|Font.ITALIC,30));
  lvety.setForeground(Color.white);
  lvety.setBounds(730,250,180,50);

  cvety=new JComboBox();
  cvvt();
  cvety.setBounds(940,260,350,30);
   cvety.addFocusListener(new FocusAdapter()
       {
         public void focusLost(FocusEvent fe)
         {

             try
             {
               Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
               Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
               Statement stmt=con.createStatement();
               String query="Select passholder from tblrate where vehicletype='"+cvety.getSelectedItem()+"'";
               ResultSet rs=stmt.executeQuery(query);
               while(rs.next())
               {
               txtamt.setText(""+rs.getInt("passholder"));
               }
  con.close();
  }
  catch(Exception e){
 System.out.println("Exception caught"+e);

}}});
  lstar=new JLabel("Issue Date");
  lstar.setFont(new Font("Corbel",Font.BOLD|Font.ITALIC,30));
  lstar.setForeground(Color.white);
  lstar.setBounds(755,300,180,50);

  txtstar=new JTextField(18);
  txtstar.setBackground(Color.white);
  txtstar.setBounds(940,310,350,27);
  txtstar.setEditable(false);

  Calendar cal=Calendar.getInstance();
  cal.add(Calendar.DAY_OF_MONTH,1);
  SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
  String s=sdf.format(new Date());
  txtstar.setText(""+s);

  lupto=new JLabel("Valid upto");
  lupto.setFont(new Font("Corbel",Font.BOLD|Font.ITALIC,30));
  lupto.setForeground(Color.white);
  lupto.setBounds(760,350,250,50);

  txtupto=new JTextField(18);
  txtupto.setBackground(Color.white);
  txtupto.setBounds(940,360,350,27);

  Calendar cal1=Calendar.getInstance();
  cal1.add(Calendar.MONTH,1);
  SimpleDateFormat sdf1=new SimpleDateFormat("dd-MM-yyyy");
  String s1=sdf1.format(cal1.getTime());
  txtupto.setText(s1);
  txtupto.setEditable(false);

  lamt=new JLabel("Amount To Pay");
  lamt.setFont(new Font("Corbel",Font.BOLD|Font.ITALIC,30));
  lamt.setForeground(Color.white);
  lamt.setBounds(700,400,250,50);

  txtamt=new JTextField(18);
  txtamt.setBackground(Color.white);
  txtamt.setBounds(940,410,350,27);
  txtamt.setEditable(false);

  p2=new ImageIcon("g1.jpg");
  btgen=new JButton(p2);
  btgen.setBounds(945,458,340,40);
  btgen.addActionListener(this);

  p3=new ImageIcon("g2.jpg");
  btbac=new JButton(p3);
  btbac.setBounds(942,518,165,40);
  btbac.addActionListener(this); 

   p4=new ImageIcon("g3.jpg");
  btcan=new JButton(p4);
  btcan.setBounds(1120,518,165,40);
  btcan.addActionListener(this); 

  c9=new ImageIcon("car4.png");
  leb9=new JLabel(c9);
  leb9.setBounds(130,600,1165,99);


add(lrun);
add(txtrun);
add(lveh);
add(txtveh);
add(lvety);
add(cvety);
add(lstar);
add(txtstar);
add(lupto);
add(txtupto);
add(lamt);
add(txtamt);
add(btgen);
add(btcan);
add(btbac);
add(leb8);
add(leb9);
add(lii);
 }

public void cvvt()
{
try
  {
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  Statement stmt=con.createStatement();
  String query="Select vehicletype from tblrate";
  ResultSet rs=stmt.executeQuery(query);
  while(rs.next())
  {
  cvety.addItem(rs.getString("vehicletype"));
  }
  con.close();
  }
  catch(Exception e){
 System.out.println("Exception caught"+e);
}}

public void actionPerformed(ActionEvent ae)
{
  String s=ae.getActionCommand();
  btgen.setActionCommand("GeneratePass");
  btcan.setActionCommand("Cancal");
  btbac.setActionCommand("Back");
  if(s.equals("GeneratePass"))
    {
     try
        {
           if(txtrun.getText().equals("") || txtveh.getText().equals("") || cvety.getSelectedItem().equals("") || txtupto.getText().equals("") || txtamt.getText().equals(""))
           {
            JOptionPane.showMessageDialog(null,"FIELDS SHOULD NOT BE EMPTY");
            int flag=1;
           }
           else{
           Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
           Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
           Statement stmt=con.createStatement();
           String query="Insert into tblnewpass(runid,vehicleno,vehicletype,issuedate,validupto,amount) values ('"+txtrun.getText()+"','"+txtveh.getText()+"','"+cvety.getSelectedItem()+"','"+txtstar.getText()+"','"+txtupto.getText()+"','"+txtamt.getText()+"')";
           int x=stmt.executeUpdate(query);
           JOptionPane.showMessageDialog(null,"Pass Generated");
           con.close();
        }}
        catch(Exception e){
                          System.out.println("Exception Caught"+e);
                          }}
   else if(s.equals("Back"))
   {
   dispose();
   adminsrc admi=new adminsrc();
   admi.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   admi.setTitle("Admin Screen");
   admi.setSize(1400,730);
   admi.setVisible(true);
   }
   else if(s.equals("Cancal"))
   {
    txtrun.setText("");
    txtveh.setText("");
    txtupto.setText("");
    txtamt.setText("");
    }
    }


public void runid()
{
   try
    {
   int a=0;
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  Statement stmt=con.createStatement();
  String query="Select runid from tblnewpass";
  ResultSet rs=stmt.executeQuery(query);
  while(rs.next())
  {
  a=rs.getInt("runid");
  }
  if(a==0)
  {
   txtrun.setText("1001");
}
   else
   {
   txtrun.setText(String.valueOf(a+1));
}
  con.close();
  }
  catch(Exception e){
 System.out.println("Exception caught"+e);
}}

public static void main(String args[])
{
  genpass gen=new genpass();
  gen.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  gen.setTitle("Generate Pass");
  gen.setSize(1400,730);
  gen.setVisible(true);
}
}