import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class showuserpass extends JFrame implements ActionListener
{
  ImageIcon c1,c2,c3,c4,c8,c9;
  JLabel luid,lnam,lpas,lc1,lc2,lc3,lh,leb8,leb9;
  JComboBox txtid;
  JTextField txtnam,txtpas;
  JButton bchng,bback,bexit;
  public showuserpass()
  {
  setLayout(null);

  c1=new ImageIcon("poiuyt.jpg");
  lc1=new JLabel(c1);
  lc1.setBounds(0,0,1400,730);

  c8=new ImageIcon("toll1.png");
  leb8=new JLabel(c8);
  leb8.setBounds(100,40,650,100);

  luid=new JLabel("User Id");
  luid.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,28));
  luid.setForeground(Color.white);
  luid.setBounds(700,290,100,50);

  txtid=new JComboBox();
  txtid();
  txtid.setBounds(820,300,350,32);
  txtid.setBackground(Color.white);
  txtid.addFocusListener(new FocusAdapter()
  {
   public void focusLost(FocusEvent fe)
   {
    try
     {
     Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
     Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
     Statement stmt=con.createStatement();
     String query="Select * from tbllogin where userid='"+txtid.getSelectedItem()+"'";
     ResultSet rs=stmt.executeQuery(query);
     while(rs.next())
     {
     txtnam.setText(rs.getString("fname")+" "+rs.getString("lname"));
     txtpas.setText(rs.getString("password"));
     }
     con.close();
     }
     catch(Exception e){
     System.out.println("Exception caught"+e);
                       }
  }
 }); 

  lnam=new JLabel("Username");
  lnam.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,28));
  lnam.setForeground(Color.white);
  lnam.setBounds(670,360,150,50);

  txtnam=new JTextField(18);
  txtnam.setBounds(820,370,350,32);
  txtnam.setBackground(Color.white);

  lpas=new JLabel("Password");
  lpas.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,28));
  lpas.setForeground(Color.white);
  lpas.setBounds(675,430,300,50);

  txtpas=new JTextField(18);
  txtpas.setBounds(820,440,350,32);
  txtpas.setBackground(Color.white);

  c2=new ImageIcon("ok.jpg");
  bchng=new JButton(c2);
  bchng.setBounds(820,495,210,38);
  bchng.addActionListener(this);

  c4=new ImageIcon("xx.jpg");
  bexit=new JButton(c4);
  bexit.setBounds(1044,495,125,38);
  bexit.addActionListener(this);

  c9=new ImageIcon("car5.png");
  leb9=new JLabel(c9);
  leb9.setBounds(110,600,1167,104);

add(luid);
add(txtid);
add(lnam);
add(txtnam);
add(lpas);
add(txtpas);
//add(lh);
add(bchng);
add(bexit);
add(leb8);
add(leb9);
add(lc1);
}

public void txtid()
{
  try
  {
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  Statement stmt=con.createStatement();
  String query="Select userid from tbllogin";
  ResultSet rs=stmt.executeQuery(query);
  while(rs.next())
  {
  txtid.addItem(rs.getString("userid"));
  }
  con.close();
  }
  catch(Exception e){
 System.out.println("Exception caught"+e);
}}


public void actionPerformed(ActionEvent ae)
{
 String s=ae.getActionCommand();
bchng.setActionCommand("Ok");
bexit.setActionCommand("Exit");
  if(s.equals("Ok"))
   {
   dispose();
   adminsrc admi=new adminsrc();
   admi.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   admi.setTitle("Admin Screen");
   admi.setSize(1400,730);
   admi.setVisible(true);
   }
else if(s.equals("Exit"))
{
int x=JOptionPane.showConfirmDialog(null,"Are You Sure??");
if(x==JOptionPane.YES_OPTION)
 {
  System.exit(0);
  }
}
}
public static void main(String args[])
{
  showuserpass pas12=new showuserpass();
  pas12.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  pas12.setTitle("Show Username/Password");
  pas12.setSize(1400,730);
  pas12.setVisible(true);
}
}