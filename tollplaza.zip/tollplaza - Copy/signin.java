import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class signin extends JFrame implements ActionListener,Runnable
{
  ImageIcon s1,s2,s3,s4,s5,s6,s7,m1,m2,m3,m4,m5,c8,c9;
  JLabel luser,lpass,li,lm,la,lg,le,leb8,leb9;
  JTextField txtid;
  JPasswordField txtpass;
  JButton butin,butit;
  public signin()
  {
  setLayout(null);
  
  s1=new ImageIcon("poiuyt.jpg");
  li=new JLabel(s1);
  li.setBounds(0,0,1400,730);

  c8=new ImageIcon("toll1.png");
  leb8=new JLabel(c8);
  leb8.setBounds(100,40,650,100);
  
  /*s2=new ImageIcon("plaza.png");
  lm=new JLabel(s2);
  lm.setBounds(10,15,730,80);*/

  m1=new ImageIcon("img11.jpg");
  la=new JLabel(m1);
  la.setBounds(5,135,818,445);

  m2=new ImageIcon("img22.jpg");

  m3=new ImageIcon("img33.jpg");
  
  m4=new ImageIcon("img44.jpg");
  
  m5=new ImageIcon("img55.jpg");

  luser=new JLabel("User Id");
  luser.setFont(new Font("Corbel",Font.BOLD|Font.ITALIC,28));
  luser.setBounds(874,300,130,50);
  luser.setForeground(Color.white);
  
  txtid=new JTextField(18);
  txtid.setBackground(Color.white);
  txtid.setBounds(985,310,350,32);

  lpass=new JLabel("Password");
  lpass.setFont(new Font("Corbel",Font.BOLD|Font.ITALIC,28));
  lpass.setBounds(840,360,130,50);
  lpass.setForeground(Color.white);
  
  txtpass=new JPasswordField(18);
  txtpass.setBackground(Color.white);
  txtpass.setBounds(985,370,350,32);

  s4=new ImageIcon("inin.jpg");
  butin=new JButton(s4);
  butin.setBounds(1008,428,284,40);
  butin.addActionListener(this);
 
  s6=new ImageIcon("xitt.jpg");
  butit=new JButton(s6);
  butit.setBounds(1072,488,151,40);
  butit.addActionListener(this);

  c9=new ImageIcon("car6.png");
  leb9=new JLabel(c9);
  leb9.setBounds(110,600,1167,96);

add(luser);
add(txtid); 
add(lpass);
add(txtpass);
add(butin);
add(leb8);
add(butit);
add(la);
add(leb9);
add(li);
  }

public void run()
{
int flag=0;
try
{
while(true)
{
Thread.sleep(2000);
if(flag==0)
{
la.setIcon(m1);
flag=1;
}
else if(flag==1)
{
la.setIcon(m2);
flag=2;
}
else if(flag==2)
{
la.setIcon(m3);
flag=3;
}
else if(flag==3)
{
la.setIcon(m4);
flag=4;
}
else if(flag==4)
{
la.setIcon(m5);
flag=0;
}
}
}
catch(Exception e){
System.out.println("Exception Caught"+e);
}
}

public void actionPerformed(ActionEvent ae)
{
  String s=ae.getActionCommand();
 /* butin.setActionCommand("signin");
  butit.setActionCommand("exit"); */
 
   if(ae.getSource()==butin)
   {
       if(txtid.getText().equals("Admin") && txtpass.getText().equals("1234567"))
                         {
                          JOptionPane.showMessageDialog(null,"LOGIN SUCCESSFUL.........");
                          dispose();
                          adminsrc admi=new adminsrc();
                          admi.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                          admi.setTitle("Admin Screen");
                          admi.setSize(1400,730);
                          admi.setVisible(true);
                         }
       else
           {
                try
                    {
                        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                        Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
                        Statement stmt=con.createStatement();
                        String query="Select * from tbllogin where userid='"+txtid.getText()+"' and password='"+txtpass.getText()+"'";
                        ResultSet rs=stmt.executeQuery(query);
                        int flag=0;
                        while(rs.next())
                        { flag=1; }  
                        if(flag==0)
                        { 
			JOptionPane.showMessageDialog(null,"Username or Password does not exist");
			txtid.setText("");
                        txtpass.setText("");
			 } 
                        else
                        {
                               JOptionPane.showMessageDialog(null,"Login Successful");
                               dispose();
                               usertype user=new usertype();
                               user.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                               user.setTitle("Payment Type");
                               user.setSize(1400,730);
                               user.setVisible(true);
                        }
                        con.close();
                    }
                catch(Exception e){
                                   System.out.println("Exception Caught"+e);
                                  }
            }
   }
   else if(ae.getSource()==butit)
   {
   int x=JOptionPane.showConfirmDialog(null,"Are You Sure?");
   if(x==JOptionPane.YES_OPTION)
   {
   System.exit(0);
   }
   }
}
public static void main(String args[])
{
  signin in=new signin();
  Thread thread=new Thread(in);
  thread.start();
  in.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  in.setTitle("User Login");
  in.setSize(1400,730);
  in.setVisible(true);
}
} 