import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class modifyuser extends JFrame implements ActionListener
{
  ImageIcon i,i1,i2,i3,i4,i5,i6,i7,c8,c9;
  JLabel l,l0,l1,l2;
  JLabel lfrst,last,lpass,lrep,lcon,lid,leb8,leb9;
  JTextField txtfrst,txtlast,txtcon,txtid;
  JComboBox cid;
  JPasswordField txtpass,txtrep;
  JButton bup,bde,bex,bcl;
  int flag=0;
  public modifyuser()
  {
  i=new ImageIcon("poiuyt.jpg");
  l1=new JLabel(i);
  l1.setBounds(0,0,1400,730);

  c8=new ImageIcon("toll1.png");
  leb8=new JLabel(c8);
  leb8.setBounds(100,20,650,100);
  
  lid=new JLabel("User Id");
  lid.setBounds(470,145,200,80);
  lid.setFont(new Font("Eras ITC", Font.BOLD|Font.ITALIC,30));
  lid.setForeground(Color.blue);

  c9=new ImageIcon("car1.png");
  leb9=new JLabel(c9);
  leb9.setBounds(200,570,937,121);

  cid=new JComboBox();
  cid();
  cid.setBackground(Color.white);
  cid.setBounds(620,170,350,30);
  cid.addFocusListener(new FocusAdapter()
  {
   public void focusLost(FocusEvent fe)
   {
    try
     {
     Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
     Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
     Statement stmt=con.createStatement();
     String query="Select * from tbllogin where userid='"+cid.getSelectedItem()+"'";
     ResultSet rs=stmt.executeQuery(query);
     while(rs.next())
     {
     txtfrst.setText(""+rs.getString("fname"));
     txtlast.setText(""+rs.getString("lname"));
     txtpass.setText(""+rs.getString("password"));
     txtcon.setText(""+rs.getString("contact")); 
     }
     con.close();
     }
     catch(Exception e){
     System.out.println("Exception caught"+e);
                       }
  }
 });

  lfrst=new JLabel("First Name");
  lfrst.setBounds(425,200,200,80);
  lfrst.setFont(new Font("Eras ITC", Font.BOLD|Font.ITALIC,30));
  lfrst.setForeground(Color.blue);

  txtfrst=new JTextField(18);
  txtfrst.setBackground(Color.white);
  txtfrst.setBounds(620,225,350,30);

  last=new JLabel("Last Name");
  last.setBounds(420,255,200,80);
  last.setFont(new Font("Eras ITC", Font.BOLD|Font.ITALIC,30));
  last.setForeground(Color.blue);

  txtlast=new JTextField(18);
  txtlast.setBackground(Color.white);
  txtlast.setBounds(620,280,350,30);

  lpass=new JLabel("Password");
  lpass.setBounds(430,310,200,80);
  lpass.setFont(new Font("Eras ITC", Font.BOLD|Font.ITALIC,30));
  lpass.setForeground(Color.blue);

  txtpass=new JPasswordField(18);
  txtpass.setBackground(Color.white);
  txtpass.setBounds(620,335,350,30);
  txtpass.setEditable(false);

  lcon=new JLabel("Contact");
  lcon.setBounds(460,365,270,80);
  lcon.setFont(new Font("Eras ITC", Font.BOLD|Font.ITALIC,30));
  lcon.setForeground(Color.blue);

  txtcon=new JTextField(18);
  txtcon.setBackground(Color.white);
  txtcon.setBounds(620,390,350,30);

  i1=new ImageIcon("bup.jpg");
  bup=new JButton(i1);
  bup.setBounds(580,450,140,36);
  bup.addActionListener(this);
 
  i4=new ImageIcon("bde.jpg");
  bde=new JButton(i4);
  bde.setBounds(730,450,140,36);
  bde.addActionListener(this);

  i5=new ImageIcon("b66.jpg");
  bcl=new JButton(i5);  
  bcl.setBounds(1230,68,120,36);
  bcl.addActionListener(this);

  i6=new ImageIcon("bex.jpg");
  bex=new JButton(i6);
  bex.setBounds(880,450,140,36);
  bex.addActionListener(this); 

  i3=new ImageIcon("ssid.jpg");
  l2=new JLabel(i3);
  l2.setBounds(600,255,650,419); 

//add(l);
add(lfrst);
add(txtfrst);
add(last);
add(txtlast);
add(lid);
add(cid);
add(lpass);
add(txtpass);
add(lcon);
add(txtcon);
add(bup);
add(bde);
add(bcl);
add(bex);
//add(l0);
//add(l2);
add(leb8);
add(leb9);
add(l1);
}

public void cid()
{
  try
  {
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  Statement stmt=con.createStatement();
  String query="Select userid from tbllogin";
  ResultSet rs=stmt.executeQuery(query);
  while(rs.next())
  {
  cid.addItem(rs.getString("userid"));
  }
  con.close();
  }
  catch(Exception e){
 System.out.println("Exception caught"+e);
}}


public void actionPerformed(ActionEvent ae)
{
  String s=ae.getActionCommand();
  bup.setActionCommand("UPDATE");
  bde.setActionCommand("DELETE");
  bcl.setActionCommand("BACK");
  bex.setActionCommand("EXIT");

   if(s.equals("UPDATE"))
   {
    try
    {
     Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
     Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
     Statement stmt=con.createStatement();
     String query="Update tbllogin set fname='"+txtfrst.getText()+"',lname='"+txtlast.getText()+"',password='"+txtpass.getText()+"',contact="+txtcon.getText().toString()+" where userid='"+cid.getSelectedItem().toString()+"'";
     int x=stmt.executeUpdate(query);
     JOptionPane.showMessageDialog(null,"USER UPDATE");
     txtfrst.setText("");
     txtlast.setText("");
     txtpass.setText("");
     txtcon.setText(""); 
     con.close();
  }
  catch(Exception e){
 System.out.println("Exception caught"+e);
}}
else if(s.equals("DELETE"))
{
try
  {
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  Statement stmt=con.createStatement();
  String query="Delete from tbllogin where userid='"+cid.getSelectedItem().toString()+"'";
  int x=stmt.executeUpdate(query);
  JOptionPane.showMessageDialog(null,"USER RECORD DELETED");
  txtfrst.setText("");
  txtlast.setText("");
  txtpass.setText("");
  txtcon.setText(""); 
  con.close();
  }

  catch(Exception e){
 System.out.println("Exception caught"+e);
}
  cid.removeAllItems();
  cid();
}
else if(s.equals("BACK"))
{
   dispose();
   adminsrc admi=new adminsrc();
   admi.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   admi.setTitle("Admin Screen");
   admi.setSize(1400,730);
   admi.setVisible(true);
}
else if(s.equals("EXIT"))
{
int x=JOptionPane.showConfirmDialog(null,"Are you sure??");
if(x==JOptionPane.YES_OPTION)
{
System.exit(0);
}}}
public static void main(String args[])
{
  modifyuser mod=new modifyuser();
  mod.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  mod.setTitle("Modified User");
  mod.setSize(1400,730);
  mod.setVisible(true);
}
}

  
  