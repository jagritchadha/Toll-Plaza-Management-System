import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import java.text.*;
public class passval extends JFrame implements ActionListener
{
  ImageIcon p1,p2,p3,p4,p5,c8,c9;
  JLabel l,lhead,lpi,lcd,lid,lvu,lpv,lvn,lvt,leb8,leb9;
  JTextField txtcd,txtid,txtvu,txtvn,txtvt;
  JComboBox cpi;
  JButton butbak,butext;
  public passval()
  {
  setLayout(null);

  p1=new ImageIcon("poiuyt.jpg");
  l=new JLabel(p1);
  l.setBounds(0,0,1400,730);

  c8=new ImageIcon("toll1.png");
  leb8=new JLabel(c8);
  leb8.setBounds(100,40,650,100);

  lpi=new JLabel("Pass Id");
  lpi.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,28));
  lpi.setForeground(Color.white);
  lpi.setBounds(435,200,110,50);

  c9=new ImageIcon("car1.png");
  leb9=new JLabel(c9);
  leb9.setBounds(200,600,937,121);

  cpi=new JComboBox();
  cpi();
  cpi.setBackground(Color.white);
  cpi.setBounds(565,205,350,30);
  cpi.addFocusListener(new FocusAdapter()
   {
      public void focusLost(FocusEvent fe)
       {
	int m;
		m=Integer.parseInt(cpi.getSelectedItem().toString());
		try
 		 {
 		 Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  		 Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  		 Statement stmt=con.createStatement();
  		 String query="Select * from tblnewpass where runid="+cpi.getSelectedItem().toString();
  		 ResultSet rs=stmt.executeQuery(query);
   		 while(rs.next())
  		 {
  		 txtvn.setText(""+rs.getString("vehicleno"));
  		 txtvt.setText(""+rs.getString("vehicletype"));
                 txtid.setText(""+rs.getString("issuedate"));
		 txtvu.setText(""+rs.getString("validupto"));
 		 }
 		 con.close();
		  }
		  catch(Exception e){
		 System.out.println("Exception caught"+e);
       		}

try
{
SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
Date validuptodt=sdf.parse(txtvu.getText());
String currdate=sdf.format(new Date());
Date curdt=sdf.parse(currdate);

if(curdt.compareTo(validuptodt)>0)
	JOptionPane.showMessageDialog(null,"Invalid Slip....");
else
	JOptionPane.showMessageDialog(null,"Valid Slip....");
}
catch(Exception e){System.out.println("Error:"+e);}

}});  

  lvn=new JLabel("Vehicle No.");
  lvn.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,28));
  lvn.setForeground(Color.white);
  lvn.setBounds(387,255,150,50);

  txtvn=new JTextField(18);
  txtvn.setBackground(Color.white);
  txtvn.setBounds(565,260,350,30);
 
  lvt=new JLabel("Vehicle Type");
  lvt.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,28));
  lvt.setForeground(Color.white);
  lvt.setBounds(365,310,180,50);

  txtvt=new JTextField(18);
  txtvt.setBackground(Color.white);
  txtvt.setBounds(565,315,350,30);

  lcd=new JLabel("Current Date");
  lcd.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,28));
  lcd.setForeground(Color.white);
  lcd.setBounds(358,365,180,50);

  txtcd=new JTextField(18);
  txtcd.setBackground(Color.white);
  txtcd.setBounds(565,370,350,30);

  SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
  String s=sdf.format(new Date());
  txtcd.setText(""+s);

  lid=new JLabel("Issue Date");
  lid.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,28));
  lid.setForeground(Color.white);
  lid.setBounds(390,420,180,50);

  txtid=new JTextField(18);
  txtid.setBackground(Color.white);
  txtid.setBounds(565,425,350,30);

  lvu=new JLabel("Valid Upto");
  lvu.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,28));
  lvu.setForeground(Color.white);
  lvu.setBounds(390,475,180,50);

  txtvu=new JTextField(18);
  txtvu.setBackground(Color.white);
  txtvu.setBounds(565,480,350,30);

  p2=new ImageIcon("b66.jpg");
  butbak=new JButton(p2);
  butbak.setBounds(570,535,160,40);
  butbak.addActionListener(this);

  p3=new ImageIcon("b7.jpg");
  butext=new JButton(p3);
  butext.setBounds(745,535,155,40);
  butext.addActionListener(this);

add(lpi);
add(cpi);
add(lvn);
add(txtvn);
add(lvt);
add(txtvt);
add(lcd);
add(txtcd);
add(lid);
add(txtid);
add(lvu);
add(txtvu);
add(butbak);
add(butext);
add(leb8);
add(leb9);
add(l);
}

public void cpi()
{
 	try
  	{
 	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  	Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  	Statement stmt=con.createStatement();
  	String query="Select runid from tblnewpass";
  	ResultSet rs=stmt.executeQuery(query);
  	while(rs.next())
  	{
  	cpi.addItem(rs.getString("runid"));
  	}
 	 con.close();
  	}
  catch(Exception e){
 System.out.println("Exception caught"+e);
}
}


public void actionPerformed(ActionEvent ae)
{
String s=ae.getActionCommand();
butbak.setActionCommand("Back");
butext.setActionCommand("Exit"); 
if(s.equals("Back"))
   {
    dispose();
    usertype user=new usertype();
    user.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    user.setTitle("Payment Type");
    user.setSize(1400,730);
    user.setVisible(true);
   } 
else if(s.equals("Exit"))
{
int x=JOptionPane.showConfirmDialog(null,"Are You Sure??");
if(x==JOptionPane.YES_OPTION)
{
System.exit(0);
}
}
}
public static void main(String args[])
{
  passval val=new passval();
  val.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  val.setSize(1400,730);
  val.setVisible(true);
}
}