import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class signup extends JFrame implements ActionListener
{
  char ch;
  ImageIcon i,i1,i2,i3,i4,i5,i6,c8,c9;
  JLabel l,l0,l1,l2;
  JLabel lfrst,last,lpass,lrep,lcon,lid,leb8,leb9;
  JTextField txtfrst,txtlast,txtcon,txtid;
  JPasswordField txtpass,txtrep;
  JButton l4,l5,l6;
  int flag=0;
  public signup()
  {
  i=new ImageIcon("poiuyt.jpg");
  l1=new JLabel(i);
  l1.setBounds(0,0,1400,730);

  c8=new ImageIcon("toll1.png");
  leb8=new JLabel(c8);
  leb8.setBounds(100,20,650,100);

  lfrst=new JLabel("First Name");
  lfrst.setBounds(120,140,200,80);
  lfrst.setFont(new Font("Eras ITC", Font.BOLD|Font.ITALIC,30));
  lfrst.setForeground(Color.white);

  txtfrst=new JTextField(18);
  txtfrst.setBackground(Color.white);
  txtfrst.setBounds(320,165,350,30);
  txtfrst.addKeyListener(new KeyAdapter(){
                public void keyReleased(KeyEvent ke){
                      try
			{
			 ch=ke.getKeyChar();
			 if((Character.isDigit(ch) || ch=='.'))
			 {
               		 JOptionPane.showMessageDialog(null,"Please enter a String value");
			 String s=txtfrst.getText();
			 txtfrst.setText(s.substring(0,s.length()-1));
			 }
		 }
		catch(Exception e){}
		}
	});

  last=new JLabel("Last Name");
  last.setBounds(125,195,200,80);
  last.setFont(new Font("Eras ITC", Font.BOLD|Font.ITALIC,30));
  last.setForeground(Color.white);

  txtlast=new JTextField(18);
  txtlast.setBackground(Color.white);
  txtlast.setBounds(320,220,350,30);
  txtlast.addKeyListener(new KeyAdapter(){
                public void keyReleased(KeyEvent ke){
                      try
			{
			 ch=ke.getKeyChar();
			 if((Character.isDigit(ch) || ch=='.'))
			 {
               		 JOptionPane.showMessageDialog(null,"Please Enter Alphabets");
			 String s=txtlast.getText();
			 txtlast.setText(s.substring(0,s.length()-1));
			 }
		 }
		catch(Exception e){}
		}
	});

  lid=new JLabel("User Id");
  lid.setBounds(165,250,200,80);
  lid.setFont(new Font("Eras ITC", Font.BOLD|Font.ITALIC,30));
  lid.setForeground(Color.white);

  txtid=new JTextField(18);
  txtid.setBackground(Color.white);
  txtid.setBounds(320,275,350,30);
  txtid.addFocusListener(new FocusAdapter()
       {
        public void focusLost(FocusEvent fe)
         {
          if(txtid.getText().length()>3)
           {
                    if(txtid.getText().indexOf('@')==-1)
                     {
	             JOptionPane.showMessageDialog(null,"USERNAME MUST CONTAIN @");
                     txtid.setText("");
                     txtid.requestFocus();
                     }
                     else
                     {
                     }
              }
             else
             {
             JOptionPane.showMessageDialog(null,"PLEASE ENTER SUFFICIENT LENGTH");
             txtid.setText("");
             //txtid.requestFocus(); 
              }
                            }});

  lpass=new JLabel("Password");
  lpass.setBounds(130,305,200,80);
  lpass.setFont(new Font("Eras ITC", Font.BOLD|Font.ITALIC,30));
  lpass.setForeground(Color.white);

  txtpass=new JPasswordField(18);
  txtpass.setBackground(Color.white);
  txtpass.setBounds(320,330,350,30);
 
  lrep=new JLabel("Re-Type Password");
  lrep.setBounds(10,360,270,80);
  lrep.setFont(new Font("Eras ITC", Font.BOLD|Font.ITALIC,30));
  lrep.setForeground(Color.white);

  txtrep=new JPasswordField(18);
  txtrep.setBackground(Color.white);
  txtrep.setBounds(320,385,350,30);
  txtrep.addFocusListener(new FocusAdapter()
       {
        public void focusLost(FocusEvent fe)
         {
           String p=txtpass.getText();
           String r=txtrep.getText();
                	if(p.equals(""+r))
               		 {
               		   if(p.length()>=7)
                            {
                                      String c=txtpass.getText();
                                       int counter=0,counter1=0;
                                                for(int i=0;i<c.length();i++)
                                                {
                                                    char ch=c.charAt(i);
                                                    if(Character.isDigit(ch))
                                                    counter++;
                                                         
                                                    if(Character.isLetter(ch))
                                                    counter1++;
                                                 }
                                                                   
                                       if(counter==0 || counter1==0)
                                                 {     
                                                     JOptionPane.showMessageDialog(null,"Password must Contain Character or numeric value");
                                                     txtpass.setText("");
                                                     txtrep.setText("");
                                                     txtpass.requestFocus();
                                                 } 
                            }
               		    else
                            {
               	                       JOptionPane.showMessageDialog(null,"PASSWORD LENGTH SHOULD BE GREATER THAN SEVEN CHAHARTERS");
                                       txtpass.requestFocus();
              	            }
         		}
          		else
                            {
                	    JOptionPane.showMessageDialog(null,"PASSWORD MUST BE SAME");
                	    txtpass.setText("");
                	    txtrep.setText("");
               		    txtpass.requestFocus();
			    }
			}});
                                                     
  lcon=new JLabel("Contact");
  lcon.setBounds(160,415,270,80);
  lcon.setFont(new Font("Eras ITC", Font.BOLD|Font.ITALIC,30));
  lcon.setForeground(Color.white);

  txtcon=new JTextField(18);
  txtcon.setBackground(Color.white);
  txtcon.setBounds(320,440,350,30);
  txtcon.addKeyListener(new KeyAdapter(){
                public void keyReleased(KeyEvent ke){
                      try
			{
			 ch=ke.getKeyChar();
			 if(!(Character.isDigit(ch) || ch=='.'))
			 {
               		 JOptionPane.showMessageDialog(null,"Please enter a numeric value");
			 String s=txtcon.getText();
			 txtcon.setText(s.substring(0,s.length()-1));
			 }
		 }
		catch(Exception e){}
		}
	});

  i4=new ImageIcon("zx1.jpg");
  l4=new JButton(i4);
  l4.setBounds(325,495,200,38);
  l4.addActionListener(this);
 
  i5=new ImageIcon("b66.jpg");
  l5=new JButton(i5);
  l5.setBounds(1230,70,120,34);
  l5.addActionListener(this);

  i6=new ImageIcon("zx2.jpg");
  l6=new JButton(i6);
  l6.setBounds(545,495,120,38);
  l6.addActionListener(this);

  i3=new ImageIcon("ssid.jpg");
  l2=new JLabel(i3);
  l2.setBounds(700,145,650,419); 
 
  c9=new ImageIcon("car2.png");
  leb9=new JLabel(c9);
  leb9.setBounds(110,580,1167,104);


//add(l);
add(lfrst);
add(txtfrst);
add(last);
add(txtlast);
add(lid);
add(txtid);
add(lpass);
add(txtpass);
add(lrep);
add(txtrep);
add(lcon);
add(txtcon);
add(l4);
add(l5);
add(l6);
//add(l0);
add(l2);
add(leb8);
add(leb9);
add(l1);
}
public void actionPerformed(ActionEvent ae)
{
 String s=ae.getActionCommand();
 l4.setActionCommand("Submit");
 l5.setActionCommand("Back");
 l6.setActionCommand("Exit");
 if(s.equals("Submit"))
  {
   try{
           if(txtfrst.getText().equals("") || txtlast.getText().equals("") || txtid.getText().equals("") ||txtpass.getText().equals("") || txtrep.getText().equals("") || txtcon.getText().equals(""))
            {
            JOptionPane.showMessageDialog(null,"FIELDS SHOULD NOT BE EMPTY");
            }
           else
           {
           Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); 
           Connection con=DriverManager.getConnection("jdbc:odbc:tollplazadsn");
           Statement stmt=con.createStatement();
           String query="Insert into tbllogin(fname,lname,userid,password,contact) values('"+txtfrst.getText()+"','"+txtlast.getText()+"','"+txtid.getText()+"','"+txtpass.getText()+"','"+txtcon.getText()+"')";
           int x=stmt.executeUpdate(query);
           JOptionPane.showMessageDialog(null,"New User Inserted");
           }
          }
           catch(Exception e)
           {
           System.out.println("Exception Caught:"+e); 
           }
}

 else if(s.equals("Back"))
 {
  dispose();
  adminsrc admi=new adminsrc();
  admi.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  admi.setTitle("Admin Screen");
  admi.setSize(1400,730);
  admi.setVisible(true);
 }
 else if(s.equals("Exit"))
 {
 int x=JOptionPane.showConfirmDialog(null,"Are You Sure??");
 if(x==JOptionPane.YES_OPTION)
 {
 System.exit(0);
 }
 }
 }
public static void main(String args[])
{
  signup up=new signup();
  up.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  up.setTitle("Create New User");
  up.setSize(1400,730);
  up.setVisible(true);
}
}  