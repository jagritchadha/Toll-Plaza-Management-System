import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class rateinsert extends JFrame implements ActionListener
{
  char ch;
  ImageIcon r1,r2,r3,r4,r5,c8,c9;
  JLabel lvvtt,lowr,ltwr,lmpr,liimm,lhed,leb8,leb9;
  JTextField txtowr,txttwr,txtmpr,txtvvtt;
  JButton lr2,lr3,lr4,lr5;
  public rateinsert()
  {
  setLayout(null);

  r1=new ImageIcon("poiuyt.jpg");
  liimm=new JLabel(r1);
  liimm.setBounds(0,0,1400,730);

  c8=new ImageIcon("toll1.png");
  leb8=new JLabel(c8);
  leb8.setBounds(100,40,650,100);

  /*lhed=new JLabel("Rate List");
  lhed.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,80));
  lhed.setForeground(Color.white);
  lhed.setBounds(30,15,700,100);*/

  lvvtt=new JLabel("Vehicle Type");
  lvvtt.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,25));
  lvvtt.setForeground(Color.blue);
  lvvtt.setBounds(770,250,180,50);

  txtvvtt=new JTextField(18);
  txtvvtt.setBackground(Color.white);
  txtvvtt.setBounds(940,260,350,27);
  txtvvtt.addKeyListener(new KeyAdapter(){
                 public void keyReleased(KeyEvent ke){
                      try
			{
			 ch=ke.getKeyChar();
			 if((Character.isDigit(ch) || ch=='.'))
			 {
               		 JOptionPane.showMessageDialog(null,"Please enter a string value");
			 String s=txtvvtt.getText();
			 txtvvtt.setText(s.substring(0,s.length()-1));
			 }
		 }
		catch(Exception e){}
		}
	});


  lowr=new JLabel("One Way Rate");
  lowr.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,25));
  lowr.setForeground(Color.blue);
  lowr.setBounds(746,300,200,50);

  txtowr=new JTextField(18);
  txtowr.setBackground(Color.white);
  txtowr.setBounds(940,310,350,25);
  txtowr.addKeyListener(new KeyAdapter(){
                 public void keyReleased(KeyEvent ke){
                      try
			{
			 ch=ke.getKeyChar();
			 if(!(Character.isDigit(ch) || ch=='.'))
			 {
               		 JOptionPane.showMessageDialog(null,"Please enter a numeric value");
			 String s=txtowr.getText();
			 txtowr.setText(s.substring(0,s.length()-1));
			 }
		 }
		catch(Exception e){}
		}
	});


  ltwr=new JLabel("Two Way Rate");
  ltwr.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,25));
  ltwr.setForeground(Color.blue);
  ltwr.setBounds(746,350,250,50);

  txttwr=new JTextField(18);
  txttwr.setBackground(Color.white);  
  txttwr.setBounds(940,360,350,25);
  txttwr.addKeyListener(new KeyAdapter(){
                 public void keyReleased(KeyEvent ke){
                      try
			{
			 ch=ke.getKeyChar();
			 if(!(Character.isDigit(ch) || ch=='.'))
			 {
               		 JOptionPane.showMessageDialog(null,"Please enter a numeric value");
			 String s=txttwr.getText();
			 txttwr.setText(s.substring(0,s.length()-1));
			 }
		 }
		catch(Exception e){}
		}
	});

  lmpr=new JLabel("Month Pass Rate");
  lmpr.setFont(new Font("Constantia",Font.BOLD|Font.ITALIC,25));
  lmpr.setForeground(Color.blue);
  lmpr.setBounds(714,400,250,50);

  txtmpr=new JTextField(18);
  txtmpr.setBackground(Color.white);
  txtmpr.setBounds(940,410,350,25);
  txtmpr.addKeyListener(new KeyAdapter(){
                 public void keyReleased(KeyEvent ke){
                      try
			{
			 ch=ke.getKeyChar();
			 if(!(Character.isDigit(ch) || ch=='.'))
			 {
               		 JOptionPane.showMessageDialog(null,"Please enter a numeric value");
			 String s=txtmpr.getText();
			 txtmpr.setText(s.substring(0,s.length()-1));
			 }
		 }
		catch(Exception e){}
		}
	});

  r2=new ImageIcon("lr2.jpg");
  lr2=new JButton(r2);
  lr2.setBounds(940,470,110,33);
  lr2.addActionListener(this);

  r3=new ImageIcon("lr3.jpg");
  lr3=new JButton(r3);
  lr3.setBounds(1060,470,110,33);
  lr3.addActionListener(this);

  r4=new ImageIcon("lr4.jpg");
  lr4=new JButton(r4);
  lr4.setBounds(1180,470,110,33);
  lr4.addActionListener(this); 

  r5=new ImageIcon("b66.jpg");
  lr5=new JButton(r5);
  lr5.setBounds(1230,80,120,35);
  lr5.addActionListener(this); 

  c9=new ImageIcon("car2.png");
  leb9=new JLabel(c9);
  leb9.setBounds(110,600,1167,104);

add(lvvtt);
add(txtvvtt);
add(lowr);
add(txtowr);
add(ltwr);
add(txttwr);
add(lmpr);
add(txtmpr);
//add(lhed);
add(lr2);
add(lr3);
add(lr4);
add(lr5);
add(leb8);
add(leb9);
add(liimm);
}

public void actionPerformed(ActionEvent ae)
{
    int a,y,z;
   /* a=Float.parseFloat(txtowr.getText());
    y=Float.parseFloat(txttwr.getText());
    z=Float.parseFloat(txtmpr.getText()); */
    String s=ae.getActionCommand();
    lr2.setActionCommand("INSERT");
    lr3.setActionCommand("CLEAR");
    lr4.setActionCommand("EXIT");
    lr5.setActionCommand("BACK");
    if(s.equals("INSERT"))
    {
    try
  {
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  Statement stmt=con.createStatement();
  String query="Insert into tblrate(vehicletype,onewayrate,twowayrate,passholder) values ('"+txtvvtt.getText()+"','"+txtowr.getText()+"','"+txttwr.getText()+"','"+txtmpr.getText()+"')";
  int x=stmt.executeUpdate(query);
  JOptionPane.showMessageDialog(null,"Rate Inserted");
  con.close();
  }
  catch(Exception e){
System.out.println("Exception Caught"+e);
}}

   else if(s.equals("CLEAR"))
   {
   txtvvtt.setText("");
   txtowr.setText("");
   txttwr.setText("");
   txtmpr.setText("");
   }

   else if(s.equals("BACK"))
   {
   dispose();
   adminsrc admi=new adminsrc();
   admi.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   admi.setTitle("Admin Screen");
   admi.setSize(1400,730);
   admi.setVisible(true);
   } 
 
   else if(s.equals("EXIT"))
   {
   int x=JOptionPane.showConfirmDialog(null,"Are You Sure?");
   if(x==JOptionPane.YES_OPTION)
    {
    System.exit(0);
   }
   }
}
public static void main(String args[])
{
  rateinsert rate=new rateinsert();
  rate.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  rate.setTitle("RateInsertion");
  rate.setSize(1400,730);
  rate.setVisible(true);
 }
}