import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;
import java.text.*;

public class oldslip extends JFrame implements ActionListener
{
  ImageIcon g1,g2,g3,g4,c8,c9;
  JLabel limgg,lhead,lsn,lvn,lvt,ljt,ldt,latp,lsvt,lig,leb8,leb9;
  JTextField txtvn,txtdt,txtatp,txtsvt,cvt,cjt;
  JComboBox txtsn;
  JButton butbac,butexi;

  public oldslip()
  {

  g1=new ImageIcon("poiuyt.jpg");
  limgg=new JLabel(g1);
  limgg.setBounds(0,0,1400,730);

  c8=new ImageIcon("toll1.png");
  leb8=new JLabel(c8);
  leb8.setBounds(100,20,650,100);

  lsn=new JLabel("Slip No.");
  lsn.setFont(new Font("Franklin Gothic",Font.BOLD|Font.ITALIC,27));
  lsn.setForeground(Color.white);
  lsn.setBounds(817,150,180,50);

  txtsn=new JComboBox();
  txtsn.setBackground(Color.white);
  txtsn();
  txtsn.setBounds(940,160,350,27);
  txtsn.addFocusListener(new FocusAdapter()
    {
	public void focusLost(FocusEvent fe)
	{
                int m;
		m=Integer.parseInt(txtsn.getSelectedItem().toString());
		try
 		 {
 		 Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  		 Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  		 Statement stmt=con.createStatement();
  		 String query="Select * from tblnewslip where slipno="+txtsn.getSelectedItem().toString();
  		 ResultSet rs=stmt.executeQuery(query);
   		 while(rs.next())
  		 {
  		 txtvn.setText(""+rs.getString("vehicleno"));
  		 cvt.setText(""+rs.getString("vehicletype"));
   		 cjt.setText(""+rs.getString("journeytype"));
                 txtatp.setText(""+rs.getString("amount"));
		 txtdt.setText(""+rs.getString("currentdate"));
                 txtsvt.setText(""+rs.getString("slipvaltime"));
 		 }
 		 con.close();
		  }
		  catch(Exception e){
		 System.out.println("Exception caught"+e);
       		}

try
{
SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy HH:mm");
Date validuptodt=sdf.parse(txtsvt.getText());
String currdate=sdf.format(new Date());
Date curdt=sdf.parse(currdate);

if(curdt.compareTo(validuptodt)>0)
	JOptionPane.showMessageDialog(null,"Invalid Slip....");
else
	JOptionPane.showMessageDialog(null,"Valid Slip....");
}
catch(Exception e){System.out.println("Error:"+e);}

}});  

  lvn=new JLabel("Vehicle No.");
  lvn.setFont(new Font("Franklin Gothic",Font.BOLD|Font.ITALIC,27));
  lvn.setForeground(Color.white);
  lvn.setBounds(775,200,200,50);

  txtvn=new JTextField(18);
  txtvn.setBackground(Color.white);
  txtvn.setBounds(940,210,350,27);
  txtvn.setEditable(false);

  lvt=new JLabel("Vehicle Type");
  lvt.setFont(new Font("Franklin Gothic",Font.BOLD|Font.ITALIC,27));
  lvt.setForeground(Color.white);
  lvt.setBounds(750,250,180,50);

  cvt=new JTextField(18);
  cvt.setBackground(Color.white);
  cvt.setBounds(940,260,350,30);
  cvt.setEditable(false);

  ljt=new JLabel("Journey Type");
  ljt.setFont(new Font("Franklin Gothic",Font.BOLD|Font.ITALIC,27));
  ljt.setForeground(Color.white);
  ljt.setBounds(738,300,180,50);

  cjt=new JTextField();
  cjt.setBackground(Color.white);
  cjt.setBounds(940,310,350,30);
  cjt.setEditable(false);

  ldt=new JLabel("Slip Date/Time");
  ldt.setFont(new Font("Franklin Gothic",Font.BOLD|Font.ITALIC,27));
  ldt.setForeground(Color.white);
  ldt.setBounds(730,350,250,50);

  txtdt=new JTextField(18);
  //txtdt.setBackground(Color.white);
  txtdt.setBounds(940,360,350,27);
  txtdt.setEditable(false);


  latp=new JLabel("Amount To Pay");
  latp.setFont(new Font("Franklin Gothic",Font.BOLD|Font.ITALIC,27));
  latp.setForeground(Color.white);
  latp.setBounds(720,400,250,50);

  txtatp=new JTextField(18);
  txtatp.setBackground(Color.white);
  txtatp.setBounds(940,410,350,27);
  txtatp.setEditable(false);

  lsvt=new JLabel("Slip Validity Time");
  lsvt.setFont(new Font("Franklin Gothic",Font.BOLD|Font.ITALIC,27));
  lsvt.setForeground(Color.white);
  lsvt.setBounds(700,450,250,50);

  txtsvt=new JTextField(18);
  txtsvt.setBackground(Color.white);
  txtsvt.setBounds(940,460,350,27);
  txtsvt.setEditable(false);

  g4=new ImageIcon("oldslp.jpg");
  lig=new JLabel(g4);
  lig.setBounds(12,240,530,405);

  g2=new ImageIcon("b33.jpg");
  butbac=new JButton(g2);
  butbac.setBounds(942,510,220,40);
  butbac.addActionListener(this);

  g3=new ImageIcon("b44.jpg");
  butexi=new JButton(g3);
  butexi.setBounds(1170,511,115,40);
  butexi.addActionListener(this);

  c9=new ImageIcon("car4.png");
  leb9=new JLabel(c9);
  leb9.setBounds(130,600,1165,99);
 
//add(lhead);
add(lsn);
add(txtsn);
add(lvn);
add(txtvn);
add(lvt);
add(cvt);
add(ljt);
add(cjt);
add(ldt);
add(txtdt);
add(latp);
add(txtatp);
add(lsvt);
//add(lig);
add(txtsvt);
add(butbac);
add(butexi);
add(leb8);
add(leb9);
add(limgg);

}
public void txtsn()
{
try
  {
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  Connection con=DriverManager.getConnection("Jdbc:Odbc:tollplazadsn");
  Statement stmt=con.createStatement();
  String query="Select slipno from tblnewslip";
  ResultSet rs=stmt.executeQuery(query);
  while(rs.next())
  {
  txtsn.addItem(rs.getString("slipno"));
  }
  con.close();
  }
  catch(Exception e){
 System.out.println("Exception caught"+e);
}}


public void actionPerformed(ActionEvent ae)
{
 String s=ae.getActionCommand();
 butbac.setActionCommand("Back");
 butexi.setActionCommand("Exit");
 if(s.equals("Back"))
 {
  dispose();
  usertype user=new usertype();
  user.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  user.setTitle("Payment Type");
  user.setSize(1400,730);
  user.setVisible(true);
 }
 else if(s.equals("Exit"))
 {
 int x=JOptionPane.showConfirmDialog(null,"ARE YOU SURE?");
 if(x==JOptionPane.YES_OPTION)
 {
 System.exit(0);
 }
 }
}
public static void main(String args[])
{
  oldslip slp=new oldslip();
  slp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  slp.setSize(1400,735);
  slp.setVisible(true);
}
}
